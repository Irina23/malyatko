﻿<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) 
  die( 'Direct Access to '.basename(__FILE__).' is not allowed.' );

class ps_pay2pay 
{

	var $classname = "ps_pay2pay";
	var $payment_code = "P2P";


function show_configuration() 
{
	global $VM_LANG;
	$db = new ps_DB();

	if(intval(@$_SERVER["SERVER_PORT"]) == 443)
		define ('SSL_URL', 'https://'.$_SERVER["SERVER_NAME"]);
	else
		define ('SSL_URL', 'http://'.$_SERVER["SERVER_NAME"]);

	include_once(CLASSPATH ."payment/".$this->classname.".cfg.php"); // Read current Configuration
	
    ?>
<table>
		 
	<tr>
		<td><strong>Merchant ID</strong></td>
		<td><input type="text" name="MERCHANT_ID" class="inputbox" value="<? echo MERCHANT_ID ?>" /></td>
		<td>Идентификатор магазина в системе Pay2Pay.com</td>
	</tr>
	<tr>
		<td><strong>Secret Key</strong></td>
		<td><input type="text" name="SECRET_KEY" class="inputbox" value="<?  echo SECRET_KEY ?>" /></td>
		<td>Секретный ключ магазина в системе Pay2Pay.com</td>
	</tr>
	<tr>
		<td><strong>Hidden Key</strong></td>
		<td><input type="text" name="HIDDEN_KEY" class="inputbox" value="<?  echo HIDDEN_KEY ?>" /></td>
		<td>Скрытый ключ магазина в системе Pay2Pay.com</td>
	</tr>

	<tr>
		<td><strong><?php echo $VM_LANG->_('PHPSHOP_ADMIN_CFG_PAYMENT_ORDERSTATUS_SUCC') ?></strong></td>
		<td>
			<select name="P2P_VERIFIED" class="inputbox" >
			<?php
				$q = "SELECT order_status_name,order_status_code FROM #__{vm}_order_status ORDER BY list_order";
				$db->query($q);
				$order_status_code = Array();
				$order_status_name = Array();
				
				while ($db->next_record()) 
				{
					$order_status_code[] = $db->f("order_status_code");
					$order_status_name[] = $db->f("order_status_name");
				}
				
				for ($i = 0; $i < sizeof($order_status_code); $i++) 
				{
					echo "<option value=\"" . $order_status_code[$i];
					if (P2P_VERIFIED == $order_status_code[$i]) 
						echo "\" selected=\"selected\">";
					else
						echo "\">";
						echo $order_status_name[$i] . "</option>\n";
				}?>
			</select>
		</td>
		<td><?php echo $VM_LANG->_('PHPSHOP_ADMIN_CFG_PAYMENT_ORDERSTATUS_SUCC_EXPLAIN') ?></td>
	</tr>
	<tr>
		<td><strong><?php echo $VM_LANG->_('PHPSHOP_ADMIN_CFG_PAYMENT_ORDERSTATUS_FAIL') ?></strong></td>
		<td>
			<select name="P2P_INVALID" class="inputbox" >
			<?php
				for ($i = 0; $i < sizeof($order_status_code); $i++) 
				{
					echo "<option value=\"" . $order_status_code[$i];
					if (P2P_INVALID == $order_status_code[$i]) 
						echo "\" selected=\"selected\">";
					else
						echo "\">";
				  echo $order_status_name[$i] . "</option>\n";
			  }
		  ?>
			</select>
		</td>
		<td><?php echo $VM_LANG->_('PHPSHOP_ADMIN_CFG_PAYMENT_ORDERSTATUS_FAIL_EXPLAIN') ?></td>
	</tr>
	<tr>
		<td><strong>Тестовый режим</strong></td>
		<td>
		<select name="P2P_TEST_MODE" class="inputbox">
      <option value="0">Нет</option>
      <option value="1" <? if (P2P_TEST_MODE == 1) {echo 'selected="selected"';} ?>>Да</option>
    </select>
		</td>
		<td>Использовать pay2pay в тестовом режиме</td>
	</tr>
</table>
<?php
}
    
function has_configuration() {
	// return false if there's no configuration
	return true;
}
   
  /**
	* Returns the "is_writeable" status of the configuration file
	* @param void
	* @returns boolean True when the configuration file is writeable, false when not
	*/
function configfile_writeable() 
{
	return is_writeable( CLASSPATH."payment/".$this->classname.".cfg.php" );
}
   
  /**
	* Returns the "is_readable" status of the configuration file
	* @param void
	* @returns boolean True when the configuration file is writeable, false when not
	*/
function configfile_readable() 
{
	return is_readable( CLASSPATH."payment/".$this->classname.".cfg.php" );
}
   
  /**
	* Writes the configuration file for this payment method
	* @param array An array of objects
	* @returns boolean True when writing was successful
	*/
function write_configuration( &$d ) 
{
	$my_config_array = array(
			"MERCHANT_ID"			=> $d['MERCHANT_ID'],
			"SECRET_KEY"			=> $d['SECRET_KEY'],
			"HIDDEN_KEY"			=> $d['HIDDEN_KEY'],
			"P2P_VERIFIED" 		=> $d['P2P_VERIFIED'],
			"P2P_INVALID"		=> $d['P2P_INVALID'],
			"P2P_TEST_MODE"			=> $d['P2P_TEST_MODE'],
        );
	$config = "<?php\n";
	$config .= "if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); \n";
/*	$config .= "if (file_exists(CLASSPATH.'payment/a_class.php'))\n";
	$config .= "include (CLASSPATH.'payment/a_class.php');\n";
	$config .= "else die(); \n\n";	*/
	foreach( $my_config_array as $key => $value ) 
	{
		$config .= "define ('$key', '$value');\n";
	}
	$config .= "?>";
  
	if ($fp = fopen(CLASSPATH ."payment/".$this->classname.".cfg.php", "w")) 
	{
		fputs($fp, $config, strlen($config));
		fclose ($fp);
		return true;
	}
	else
		return false;
}
   
  /**************************************************************************
  ** name: process_payment()
  ** returns: 
  ***************************************************************************/
function process_payment($order_number, $order_total, &$d) {
      return true;
    }
 
}