<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
define ('MERCHANT_ID', '');
define ('SECRET_KEY', '');
define ('HIDDEN_KEY', '');
define ('P2P_VERIFIED', 'C');
define ('P2P_INVALID', 'X');
define ('P2P_TEST_MODE', '1');
?>