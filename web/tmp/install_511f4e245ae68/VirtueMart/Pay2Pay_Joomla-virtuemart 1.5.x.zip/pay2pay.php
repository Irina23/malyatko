﻿<?php
ini_set("display_errors","0");

global $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_lang, $database,
$mosConfig_mailfrom, $mosConfig_fromname;

    /*** access Joomla's configuration file ***/
    $my_path = dirname(__FILE__);
    
    if( file_exists($my_path."/../../../configuration.php")) {
        $absolute_path = dirname( $my_path."/../../../configuration.php" );
        require_once($my_path."/../../../configuration.php");
    }
    elseif( file_exists($my_path."/../../configuration.php")){
        $absolute_path = dirname( $my_path."/../../configuration.php" );
        require_once($my_path."/../../configuration.php");
    }
    elseif( file_exists($my_path."/../configuration.php")){
        $absolute_path = dirname( $my_path."/../configuration.php" );
        require_once($my_path."/../configuration.php");
    }
    elseif( file_exists($my_path."/configuration.php")){
        $absolute_path = dirname( $my_path."/configuration.php" );
        require_once( $my_path."/configuration.php" );
    }
    else {
        die( "Joomla Configuration File not found!" );
    }
    
    $absolute_path = realpath( $absolute_path );
    
    // Set up the appropriate CMS framework
    if( class_exists( 'jconfig' ) ) {
		define( '_JEXEC', 1 );
		define( 'JPATH_BASE', $absolute_path );
		define( 'DS', DIRECTORY_SEPARATOR );
		
		// Load the framework
		require_once ( JPATH_BASE . DS . 'includes' . DS . 'defines.php' );
		require_once ( JPATH_BASE . DS . 'includes' . DS . 'framework.php' );

		// create the mainframe object
		$mainframe = & JFactory::getApplication( 'site' );
		
		// Initialize the framework
		$mainframe->initialise();
		
		// load system plugin group
		JPluginHelper::importPlugin( 'system' );
		
		// trigger the onBeforeStart events
		$mainframe->triggerEvent( 'onBeforeStart' );
		$lang =& JFactory::getLanguage();
		$mosConfig_lang = $GLOBALS['mosConfig_lang'] = strtolower( $lang->getBackwardLang() );
		// Adjust the live site path
		$mosConfig_live_site = str_replace('/administrator/components/com_virtuemart', '', JURI::base());
		$mosConfig_absolute_path = JPATH_BASE;
    } else {
    	define('_VALID_MOS', '1');
    	require_once($mosConfig_absolute_path. '/includes/joomla.php');
    	require_once($mosConfig_absolute_path. '/includes/database.php');
    	$database = new database( $mosConfig_host, $mosConfig_user, $mosConfig_password, $mosConfig_db, $mosConfig_dbprefix );
    	$mainframe = new mosMainFrame($database, 'com_virtuemart', $mosConfig_absolute_path );
    }

    // load Joomla Language File
    if (file_exists( $mosConfig_absolute_path. '/language/'.$mosConfig_lang.'.php' )) {
        require_once( $mosConfig_absolute_path. '/language/'.$mosConfig_lang.'.php' );
    }
    elseif (file_exists( $mosConfig_absolute_path. '/language/english.php' )) {
        require_once( $mosConfig_absolute_path. '/language/english.php' );
    }
/*** END of Joomla config ***/


/*** VirtueMart part ***/
	global $database;        
    require_once($mosConfig_absolute_path.'/administrator/components/com_virtuemart/virtuemart.cfg.php');
    include_once( ADMINPATH.'/compat.joomla1.5.php' );
    require_once( ADMINPATH. 'global.php' );
    require_once( CLASSPATH. 'ps_main.php' );
    require_once( CLASSPATH. 'ps_database.php' );
    require_once( CLASSPATH. 'ps_order.php' );

    $vmLogIdentifier = "pay2pay.php";
    require_once(CLASSPATH."Log/LogInit.php");
    require_once( CLASSPATH. 'payment/ps_pay2pay.cfg.php' );
    $sess = new ps_session();                        
    
/*** END VirtueMart part ***/



function SetOrderStatus ($order_id = false, $status) {
		if ($order_id)
		{
			$d['order_id'] = $order_id;
			$d['notify_customer'] = "N";
			$d['order_status'] = $status;                    
			$ps_order= new ps_order;
			$ps_order->order_status_update($d);
		}		
		die;
}

$xml = base64_decode(str_replace(' ', '+', $_REQUEST['xml']));
$sign = base64_decode(str_replace(' ', '+', $_REQUEST['sign']));

if ($xml)
{
  $vars = simplexml_load_string($xml);
  
  $ar_req['version']     = $vars->version;
  $ar_req['merchant_id'] = $vars->merchant_id;
  $ar_req['order_id']    = $vars->order_id;
  $ar_req['amount']      = $vars->amount;
  $ar_req['currency']    = $vars->currency;
  $ar_req['description'] = $vars->description;
  $ar_req['paymode']     = $vars->paymode;
  $ar_req['trans_id']    = $vars->trans_id;
  $ar_req['status']      = $vars->status;
  $ar_req['error_msg']   = $vars->error_msg;
  
  $order = intval($ar_req['order_id']);
  if ($order > 0)
  {
  	$amount = $ar_req['amount'];
  	$odid = intval($ar_req['trans_id']);
  
  	$qv = "SELECT `order_id`, `order_number`, `user_id`, `order_subtotal`,
                      `order_total`, `order_currency`, `order_tax`, `order_status`, 
                      `order_shipping_tax`, `coupon_discount`, `order_discount`, `ip_address`
                  FROM `#__{vm}_orders` 
                  WHERE `order_id`='".$order."'";
  
  	$db_ap = new ps_DB;
  	$query = $db_ap->query($qv);		
  	$db_ap->query($qv);
  	$db_ap->next_record();
  	$order_id = @$db_ap->f('order_id');
  	$order_status = @$db_ap->f('order_status');
  	$order_total = round($db_ap->f('order_total'), 2);

  	if (!$order_id OR $order_id=="") 
  	{
  		echo '<?xml version="1.0" encoding="UTF-8"?><result><status>no</status><error_msg>Unknow order ID</error_msg></result>';
  		die;
  	}
  	elseif (md5(HIDDEN_KEY.$xml.HIDDEN_KEY) != $sign) 
  	{
  		echo '<?xml version="1.0" encoding="UTF-8"?><result><status>no</status><error_msg>Security check failed</error_msg></result>';
  		SetOrderStatus($order,P2P_INVALID);
  	}
  	elseif ($order_status == P2P_VERIFIED) 
  	{
    		echo '<?xml version="1.0" encoding="UTF-8"?><result><status>no</status><error_msg>Duplicate payment</error_msg></result>';
  		SetOrderStatus($order,P2P_INVALID);
	}
	elseif ($order_total != $amount) 
	{
		echo '<?xml version="1.0" encoding="UTF-8"?><result><status>no</status><error_msg>Incorrect amount</error_msg></result>';
  		SetOrderStatus($order,P2P_INVALID);
	}
	else
	{
		echo '<?xml version="1.0" encoding="UTF-8"?><result><status>yes</status><error_msg></error_msg></result>';
		if ($ar_req['status'] == 'success')
  			SetOrderStatus($order,P2P_VERIFIED);
  		else
  			SetOrderStatus($order,P2P_INVALID);
	}
  }
  else
    echo '<?xml version="1.0" encoding="UTF-8"?><result><status>no</status><error_msg>Invalid order ID</error_msg></result>';
}
else 
{
  $link = "http://".CURRENT_SITE."/index.php?page=account.index&option=com_virtuemart";
  header("Location: ".$link);
}
?>