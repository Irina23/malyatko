<?php include(dirname(__FILE__)."/language.ru.php"); 
?>
<div class="col100">
<fieldset class="adminform">
<table class="admintable" width = "100%" >
  <tr>
		<td width="300"><strong><?=ADMIN_CFG_PAY2PAY_MERCHANT_ID?>:</strong></td>
		<td>
			<input type="text" name = "pm_params[pay2pay_merchant_id]" class="inputbox" value="<?=$params['pay2pay_merchant_id']?>" />
		</td>
		<td><?=ADMIN_CFG_PAY2PAY_MERCHANT_ID_DESCRIPTION?></td>
  </tr>
	<tr>
		<td><strong><?=ADMIN_CFG_PAY2PAY_SECRET_KEY?>:</strong></td>
		<td>
			<input type="text"name = "pm_params[pay2pay_secret_key]" class="inputbox" value="<?=$params['pay2pay_secret_key']?>" />
		</td>
	  <td><?=ADMIN_CFG_PAY2PAY_SECRET_KEY_DESCRIPTION?></td>
	</tr>
	<tr>
		<td><strong><?=ADMIN_CFG_PAY2PAY_HIDDEN_KEY?>:</strong></td>
		<td>
			<input type="text"name = "pm_params[pay2pay_hidden_key]" class="inputbox" value="<?=$params['pay2pay_hidden_key']?>" />
		</td>
	  <td><?=ADMIN_CFG_PAY2PAY_HIDDEN_KEY_DESCRIPTION?></td>
	</tr>
 	<tr>
		<td><strong><?=ADMIN_CFG_PAY2PAY_TEST_MODE?>:</strong></td>
		<td>
		  <?php print JHTML::_('select.booleanlist', 'pm_params[pay2pay_test_mode]', 'class = "inputbox" size = "1"', $params['pay2pay_test_mode']);?> 
		</td>
		<td><?=ADMIN_CFG_PAY2PAY_TEST_MODE_DESCRIPTION?></td>
	</tr>
	<tr>
		<td><strong><?=ADMIN_CFG_PAY2PAY_PAYMODE?>:</strong></td>
		<td>
			<input type="text"name = "pm_params[pay2pay_paymode]" class="inputbox" value="<?=$params['pay2pay_paymode']?>" />
		</td>
		<td><?=ADMIN_CFG_PAY2PAY_PAYMODE_DESCRIPTION?></td>
	</tr>
  <tr>
    <td class="key"><strong><?php echo _JSHOP_TRANSACTION_END;?>:</strong></td>
    <td>
      <?php print JHTML::_('select.genericlist', $orders->getAllOrderStatus(), 'pm_params[pay2pay_transaction_end_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['pay2pay_transaction_end_status'] );?>
    </td>
  </tr>
  <tr>
    <td class="key"><strong><?php echo _JSHOP_TRANSACTION_PENDING;?>:</strong></td>
    <td>
      <?php echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[pay2pay_transaction_pending_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['pay2pay_transaction_pending_status']);?>
    </td>
  </tr>
  <tr>
    <td class="key"><strong><?php echo _JSHOP_TRANSACTION_FAILED;?>:</strong></td>
    <td>
      <?php echo JHTML::_('select.genericlist',$orders->getAllOrderStatus(), 'pm_params[pay2pay_transaction_failed_status]', 'class = "inputbox" size = "1"', 'status_id', 'name', $params['pay2pay_transaction_failed_status']);?>
   </td>
 </tr>
</table>
</fieldset>
</div>
<div class="clr"></div>