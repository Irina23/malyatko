<?php
defined('_JEXEC') or die('Restricted access');

class pm_pay2pay extends PaymentRoot
{
	function showAdminFormParams($params){
	  $array_params = array('pay2pay_merchant_id', 'pay2pay_secret_key', 'pay2pay_hidden_key', 'pay2pay_test_mode', 'pay2pay_paymode', 'transaction_end_status', 'transaction_pending_status', 'transaction_failed_status');
	  foreach ($array_params as $key)
	  	if (!isset($params[$key])) $params[$key] = '';
	  
	  $orders = &JModel::getInstance('orders', 'JshoppingModel'); 
    include(dirname(__FILE__)."/adminparamsform.php");	  
	}

    function showPaymentForm($params, $pmconfigs){
        include(dirname(__FILE__)."/paymentform.php");
    }

	function checkTransaction($pmconfigs, $order, $act){
    return array(1, '');     
	}
  function nofityFinish($pmconfigs, $order, $act)
  {
    include(dirname(__FILE__)."/pay2pay_notify.php");
  }
	function showEndForm($pmconfigs, $order)
	{
		$amount = floatval($order->order_total);
		$currency = $order->currency_code_iso;
		if ($currency == 'RUR')
		  $currency = 'RUB';
		$desc = sprintf(_JSHOP_PAYMENT_NUMBER, $order->order_number);
		
		$result_url = JURI::root() . "index.php?option=com_jshopping&controller=checkout&task=step7&act=notify&js_paymentclass=pm_pay2pay&no_lang=1&order_id=".$order->order_id;
		$success_url = JURI::root(). "index.php?option=com_jshopping&controller=checkout&task=step7&act=return&js_paymentclass=pm_pay2pay";
		$fail_url = JURI::root() . "index.php?option=com_jshopping&controller=checkout&task=step7&act=cancel&js_paymentclass=pm_pay2pay";
		
		$xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
		<request>
		<version>1.2</version>
		<merchant_id>".$pmconfigs['pay2pay_merchant_id']."</merchant_id>
		<language>ru</language>
		<order_id>$order->order_id</order_id>
		<amount>$amount</amount>
		<currency>$currency</currency>
		<description>$desc</description>
		<paymode><code>".$pmconfigs['pay2pay_paymode']."</code></paymode>
		<success_url><![CDATA[$success_url]]></success_url>
		<fail_url><![CDATA[$fail_url]]></fail_url>
		<result_url><![CDATA[$result_url]]></result_url>";
		if ($pmconfigs['pay2pay_test_mode'])
		  $xml .= "<test_mode>1</test_mode>";
		$xml .= "</request>";
		
		$xml_encoded = base64_encode($xml);
		$sign_encoded = base64_encode(md5($pmconfigs['pay2pay_secret_key'].$xml.$pmconfigs['pay2pay_secret_key']));
		
		$html = '<form method="post" action="https://merchant.pay2pay.com/?page=init"name="paymentform">';
		$html .= '<input type="hidden" name="xml" value="'.$xml_encoded.'">';
		$html .= '<input type="hidden" name="sign" value="'.$sign_encoded.'">';
		//$html .= '<input type="submit">';
		$html .= '</form>';
		$html .= '<script type="text/javascript">';
		$html .= 'document.forms.paymentform.submit();';
		$html .= '</script>';
		
		print _JSHOP_REDIRECT_TO_PAYMENT_PAGE;
		die($html);
	}
	function getUrlParams($pmconfigs){
	  $params = array();
	  $params['order_id'] = JRequest::getInt("order_id");
	  $params['hash'] = "";
	  $params['checkHash'] = 0;
	  $params['checkReturnParams'] = $pmconfigs['checkdatareturn'];
	  return $params;
	}
}
?>