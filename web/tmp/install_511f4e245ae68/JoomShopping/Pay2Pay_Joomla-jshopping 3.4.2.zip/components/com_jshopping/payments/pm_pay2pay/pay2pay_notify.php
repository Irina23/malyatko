<?
error_reporting (0);

if (isset($_REQUEST['xml']) and isset($_REQUEST['sign']))
{
  define('_JEXEC', 1);
	define('DS', DIRECTORY_SEPARATOR);
	$option='com_jshopping';
	$my_path = dirname(__FILE__);
	$my_path = explode(DS.'components',$my_path);	
	$my_path = $my_path[0];			
	if (file_exists($my_path . '/defines.php'))
		include_once $my_path . '/defines.php';

	if (!defined('_JDEFINES'))
	{
		define('JPATH_BASE', $my_path);
	  require_once JPATH_BASE.'/includes/defines.php';
  }
	
  define('JPATH_COMPONENT',				JPATH_BASE . '/components/' . $option);
	define('JPATH_COMPONENT_SITE',			JPATH_SITE . '/components/' . $option);
	define('JPATH_COMPONENT_ADMINISTRATOR',	JPATH_ADMINISTRATOR . '/components/' . $option);
	
	require_once JPATH_BASE.'/includes/framework.php';
	$app = JFactory::getApplication('site');
	$app->initialise();
	
	JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
	jimport('joomla.application.component.model'); 
	JModel::addIncludePath(JPATH_COMPONENT.DS.'models');
	
	require_once (JPATH_COMPONENT_SITE."/lib/factory.php");
	require_once (JPATH_COMPONENT_SITE.'/lib/functions.php');
	include_once(JPATH_COMPONENT_SITE."/controllers/checkout.php");

  $error = '';
 
	$xml_post = base64_decode(str_replace(' ', '+', $_REQUEST['xml']));
	$sign_post = base64_decode(str_replace(' ', '+', $_REQUEST['sign']));

  $vars = simplexml_load_string($xml_post);
  if ($vars->order_id)
  {
    $order = &JTable::getInstance('order', 'jshop');
    $order->load($vars->order_id);

    if ($order->order_id)
    {
      $pm_method = &JTable::getInstance('paymentMethod', 'jshop');
      $pm_method->load($order->payment_method_id);
      $pmconfigs = $pm_method->getConfigs();
      
      if ($order->order_status == $pmconfigs['pay2pay_transaction_pending_status'])
      {
      	$sign = md5($pmconfigs['pay2pay_hidden_key'].$xml_post.$pmconfigs['pay2pay_hidden_key']);
        if ($sign_post == $sign)
      	{
        	$currency = $order->currency_code_iso;
        	if ($currency == 'RUR')
        	  $currency = 'RUB';
        	
      	  if (strtoupper($currency) == $vars->currency)
      	  {
      	    if (ceil($order->order_total*100)/100 <= $vars->amount)
      	    {
      	      if (($vars->type == 'result') and ($vars->status == 'success' or $vars->status == 'fail'))
      	      {
      	        $status = $pmconfigs['pay2pay_transaction_failed_status'];
      	        if ($vars->status == 'success')
      	          $status = $pmconfigs['pay2pay_transaction_end_status'];
      	        
      	        if ($status && !$order->order_created)
      	        {
      	          $order->order_created = 1;
      	          $order->order_status = $status;
      	          $order->store();
      	          $pay_class = new JshoppingControllerCheckout();
      	          $pay_class->_sendOrderEmail($order->order_id);
      	          $order->changeProductQTYinStock("-");
      	          $pay_class->_changeStatusOrder($order->order_id, $status, 0);
      	          $rtrn = true;
      	        }
      	        
      	        if ($status && $order->order_status != $status)
      	        {
      	          $this->_changeStatusOrder($order_id, $status, 1);
      	          $rtrn=true;
      	        }
      	      }
      	    }
      	    else
      	      $error = 'Amount check failed';
      	  }
      	  else
      	    $error = 'Currency check failed';
      	}
      	else
      	  $error = 'Security check failed';
    	}
    	else
    	  $error = 'Payment is not expected';
  	}
  	else
  	  $error = 'Unknown order_id';
  }
	else
	  $error = 'Incorrect order_id';
	
	if ($error != '')
	  $ret = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><response><status>yes</status><err_msg></err_msg></response>";
	else
	  $ret = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><response><status>no</status><err_msg>$error</err_msg></response>";
	
  die($ret);	
}
?>
