<script type="text/javascript">
function check_pm_pay2pay(){
    $_('payment_form').submit();
}
</script>