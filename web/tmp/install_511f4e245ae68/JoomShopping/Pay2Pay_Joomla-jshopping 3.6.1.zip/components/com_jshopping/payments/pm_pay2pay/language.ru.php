﻿<?php
define ('ADMIN_CFG_PAY2PAY_MERCHANT_ID', 'Merchant ID');
define ('ADMIN_CFG_PAY2PAY_MERCHANT_ID_DESCRIPTION', 'Идентификатор магазина в системе Pay2Pay');
define ('ADMIN_CFG_PAY2PAY_SECRET_KEY', 'Секретный ключ');
define ('ADMIN_CFG_PAY2PAY_SECRET_KEY_DESCRIPTION', 'Секретный ключ');
define ('ADMIN_CFG_PAY2PAY_HIDDEN_KEY', 'Скрытый ключ');
define ('ADMIN_CFG_PAY2PAY_HIDDEN_KEY_DESCRIPTION', 'Скрытый ключ');
define ('ADMIN_CFG_PAY2PAY_TEST_MODE', 'Тестовый режим');
define ('ADMIN_CFG_PAY2PAY_TEST_MODE_DESCRIPTION', 'В тестовом режиме не проводятся реальные платежи, преднозначен для отладки взаимодействия сервисов.');
define ('ADMIN_CFG_PAY2PAY_PAYMODE', 'Способ оплаты');
define ('ADMIN_CFG_PAY2PAY_PAYMODE_DESCRIPTION', 'Код для предопределения способа оплаты');

define ('PAY2PAY_ERROR_INCORRECT_SIGN', 'Подпись не совпадает');
define ('PAY2PAY_ERROR_WRONG_ORDER_NUMBER', 'Неправильный номер заказа');
define ('PAY2PAY_ERROR_INCORRECT_CURRENCY', 'Не совпадает валюта');
define ('PAY2PAY_ERROR_INCORRECT_AMOUNT', 'Не совпадает сумма');

define ('PAY2PAY_PAY', 'Оплатить');
?>