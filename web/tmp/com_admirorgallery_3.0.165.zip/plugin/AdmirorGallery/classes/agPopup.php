<?php
/**
 * Description of agPopup
 *
 * @author Nikola Vasiljevski
 */
class agPopup {

        var $customAttr='';
        var $rel='';
        var $className='';
        var $jsInclude = '';
        var $initCode='';
	var $customPopupThumb='';
	var $endCode='';

}
?>
