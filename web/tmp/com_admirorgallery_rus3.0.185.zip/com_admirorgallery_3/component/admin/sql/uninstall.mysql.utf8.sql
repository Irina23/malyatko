DROP TABLE IF EXISTS `#__ag_galleries`;

DROP TABLE IF EXISTS `#__ag_images`;

DROP TABLE IF EXISTS `#__ag_captions`;